console.log("routes.js is loading!!!!");

module.exports = function(app){

}
