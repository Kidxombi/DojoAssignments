//
//  ComBeastListViewController.swift
//  BeastListBB
//
//  Created by Samuel on 3/30/17.
//  Copyright © 2017 swift/learn. All rights reserved.
//

import Foundation
import UIKit
import Foundation

class ComBeastListViewController: UITableViewController {
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    
}
