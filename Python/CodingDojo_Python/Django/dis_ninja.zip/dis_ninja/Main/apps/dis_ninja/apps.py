from __future__ import unicode_literals

from django.apps import AppConfig


class DisNinjaConfig(AppConfig):
    name = 'dis_ninja'
