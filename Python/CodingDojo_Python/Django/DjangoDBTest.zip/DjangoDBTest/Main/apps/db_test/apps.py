from __future__ import unicode_literals

from django.apps import AppConfig


class DbTestConfig(AppConfig):
    name = 'db_test'
